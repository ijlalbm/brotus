//all js 
$("form").attr('autocomplete', 'off');