<li class="treeview active">
                    
                    <a href="javascript:void(0)">
                        <i class="fa fa-facebook"></i> <span><?php echo display('add_facebook_app');?></span>
                        <span class="pull-right-container">
                            <i class="fa fa-angle-left pull-right"></i>
                        </span>
                    </a> 

                    <ul class="treeview-menu menu-open">
                     <li class="treeview"><a href="<?php echo base_url('facebooklogin/facebookloginback/showsetting') ?>"><i class="fa fa-hand-o-right"></i><span><?php echo display('facebook_api');?></span> </a></li>
 					 
                     
                    </ul>
                </li>